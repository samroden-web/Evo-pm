// Client, framework and accreditation logos.
// src: null means the file is still to come. The logo strip then shows the name in a
// neutral tile with a TBC tag, so nothing breaks. Drop the file into /public and set src.
//
// `withFiles` is what the homepage uses. Six of the eleven client logos are still
// placeholders, and a band of yellow TBC boxes directly under the headline figures
// undercuts the figures rather than supporting them. The full client list, placeholders
// and all, still appears on /about, which is where EVO wants to see what is outstanding.

export const clientLogos = [
  { name: 'B&D Reside', src: null, tbc: 'logo file to follow' },
  { name: 'IDS', src: null, tbc: 'logo file to follow' },
  // TBC item 16: clean file to follow (the current logo shows a ghosted duplicate).
  { name: 'Thames Reach', src: null, tbc: 'logo file to follow' },
  { name: 'Soho Housing', src: null, tbc: 'logo file to follow' },
  { name: 'LRM', src: null, tbc: 'logo file to follow' },
  { name: 'British Land', src: null, tbc: 'logo file to follow' },
  { name: 'Capital Letters', src: null, tbc: 'logo file to follow' },
  { name: 'Resonance', src: null, tbc: 'logo file to follow' },
  // Added 24 Sep 2026 (addendum v2, section 1): recent wins.
  { name: 'Greenhill Housing', src: null, tbc: 'logo file to follow' },
  { name: 'Storm Housing Group', src: null, tbc: 'logo file to follow' },
  { name: 'J49', src: null, tbc: 'logo file to follow' },
];

// Only the logos we actually hold files for. Used on the homepage.
export const withFiles = (logos) => logos.filter((l) => l.src);

export const frameworkLogos = [
  { name: 'G-Cloud supplier', src: '/images/logos/accreditations/g-cloud.png', width: 600, height: 179 },
  {
    name: 'Crown Commercial Service supplier',
    src: '/images/logos/accreditations/crown-commercial-service.png',
    width: 600,
    height: 247,
  },
  // TBC item 13: keep only if EVO confirms these are current. Set show: true to display.
  { name: 'South East Consortium', src: null, tbc: 'logo file to follow', show: true },
  { name: 'Procurement for Housing', src: null, tbc: 'logo file to follow', show: true },
];

export const accreditationLogos = [
  {
    name: 'ISO 9001, 14001 and 45001',
    src: '/images/logos/accreditations/iso-9001-14001-45001.png',
    width: 500,
    height: 205,
  },
  { name: 'ISO 27001', src: '/images/logos/accreditations/iso-27001.png', width: 600, height: 391 },
  {
    name: 'Constructionline Gold member',
    src: '/images/logos/accreditations/constructionline-gold.png',
    width: 270,
    height: 179,
  },
  { name: 'Acclaim Accreditation', src: '/images/logos/accreditations/acclaim.png', width: 357, height: 121 },
  { name: 'Property Redress Scheme', src: '/images/logos/accreditations/prs.webp', width: 600, height: 170 },
  { name: 'Cyber Essentials', src: '/images/logos/accreditations/cyber-essentials.png', width: 95, height: 114 },
  { name: 'Living Wage Employer', src: '/images/logos/accreditations/living-wage-employer.png', width: 140, height: 111 },
];

export const awardBadges = null;

// Tone correction for the client strip.
//
// THE FINDING. The nine logos that came off the old Umbraco site are not grey because a CSS
// filter greys them - they are grey ARTWORK, deliberately normalised to a mid-tone of about
// 0.7 to 0.8 luminance by whoever prepared them. Greenhill and J49 came later, from the
// clients' own sites, and are full-strength near-black marks at about 0.32. Desaturating
// removes hue but not tone, which is why those two still read as noticeably heavier.
//
// WHY OPACITY AND NOT BRIGHTNESS. brightness() was tried first and cannot do this: at the
// multiplier Greenhill needs, 63% of J49's mark clipped to solid white. You cannot lift a
// dark mark to a mid-tone by multiplying without destroying it. Opacity blends toward the
// page behind it instead, which is exactly the effect wanted and has no clipping at all.
//
// THE NUMBERS. Solving o for  o*ink + (1-o)*background = 0.772,  where 0.772 is what a
// normal logo renders at (its 0.75 ink at the strip's default 0.8 opacity) and the strip
// background is about 0.97:
//
//   Greenhill  ink 0.32 -> 0.31      J49    ink 0.34 -> 0.32
//   Storm      ink 0.57 -> 0.49      LRM    ink 0.65 -> 0.62
//
// Anything not listed is already at the right tone and keeps the default.
//
// TO RE-MEASURE after adding a logo: average the luminance of its non-transparent pixels,
// ignoring anything above 0.93 (the white plate most of these sit on), then solve the line
// above for o. If a new logo arrives already greyed to match the old set, it needs nothing.
// TONE. Sam, 27 September: "The south east consortium logo has white text which is why we cant
// see the writing on the light backgrounds. can nyou change the colour of that writing so it
// shows up?" It is white artwork on transparent, so on every light band on this site it is an
// invisible word beside a visible symbol.
//
// `brightness(0)` collapses every non-transparent pixel to black while leaving the transparency
// alone, which turns white lettering into dark lettering without touching the file. The artwork
// EVO was given is not altered or recoloured in any brand sense - it is rendered as a
// single-tone mark, which is how the accreditation bodies publish these for light backgrounds
// anyway. `logoOpacity` then lifts it back off pure black so it sits with the other marks.
//
// WHY THIS IS A SEPARATE MAP AND NOT A FIELD ON THE LOGO. tools/link-client-logos.mjs REBUILDS
// each logo's object literal from scratch on every deploy, keeping only src, width, height,
// show and tbc. Any other field put on the entry is silently deleted the next time a patch is
// deployed - the white text would come back and nobody would connect it to a logo re-fetch. Put
// display decisions here, where the linker cannot reach them.
export const logoTone = {
  'South East Consortium': 'light-artwork',
};

export const logoOpacity = {
  'Greenhill Housing': 0.31,
  J49: 0.32,
  'Storm Housing Group': 0.49,
  LRM: 0.62,
  // Not a tone measurement - this one is a brightness(0) mark (see logoTone above), lifted off
  // pure black so it reads as the same weight as the greyed logos beside it.
  'South East Consortium': 0.72,
};
