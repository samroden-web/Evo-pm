import Link from 'next/link';
import PageHero from '@/components/PageHero';
import SectionHead from '@/components/SectionHead';
import Photo from '@/components/Photo';
import { IconBadge } from '@/components/Icon';
import { cta } from '@/data/site';

export const metadata = {
  title: 'Compliance: statutory and regulatory | EVO',
  description:
    'Statutory compliance is work we do: gas, EICRs, PAT, alarms. Regulatory compliance is a duty that stays with you, and we hold the evidence for it.',
  alternates: { canonical: '/compliance' },
};

const REGULATORY = [
  {
    icon: 'shieldCheck',
    k: 'Consumer standards',
    h: 'Graded C1 to C4, and published.',
    b: 'The Safety and Quality Standard covers repairs and stock condition. Inspections look for evidence that the standard is met, not assurances that it is.',
  },
  {
    icon: 'chart',
    k: 'Tenant Satisfaction Measures',
    h: 'Reported annually, compared across the sector.',
    b: 'Repairs satisfaction and time taken are two of the measures. Both are outcomes of how repairs actually run, not of how they are reported.',
  },
  {
    icon: 'clock',
    k: "Awaab's Law",
    h: 'Fixed timescales, widening on 30 November 2026.',
    b: 'In force for damp and mould today. Phase 2 extends to cold, heat, fire, electrical and structural hazards. Meeting the timescale is one job; evidencing it is another.',
  },
  {
    icon: 'scales',
    k: 'The Housing Ombudsman',
    h: 'Determinations turn on the record.',
    b: 'Complaint handling is judged on whether you can show what happened and when, not on whether the repair was eventually done.',
  },
];

const RECORDED = [
  ['At report', 'What the resident said, in their words, with their photographs and a timestamp.'],
  ['At triage', 'The priority applied, the timescale that follows from it, and who made the call.'],
  ['On attendance', 'Arrival time, the trade who attended, and photographs before work starts.'],
  ['On completion', 'What was done, what was used, photographs after, and the resident’s rating.'],
  [
    'On no access',
    'The visit, the evidence of attendance, and the attempt to make contact. The record landlords most often cannot produce.',
  ],
  ['On repeat', 'Any return visit linked to the original job, so repeat work is visible rather than buried.'],
];

export default function CompliancePage() {
  return (
    <>
      <PageHero
        eyebrow="Compliance"
        title="Two kinds of compliance, split properly."
        lead="One is a certificate with a date on it. The other is a judgement the Regulator makes about you. Suppliers who blur the two are usually overclaiming on the second."
        crumbs={[{ label: 'Compliance' }]}
      >
        <div className="btn-row mt-3">
          <Link href={cta.review.href} className="btn btn-primary">
            {cta.review.label}
          </Link>
          <Link href="/damp-and-mould" className="btn btn-secondary">
            Damp and mould
          </Link>
        </div>
      </PageHero>

      <section className="section">
        <div className="container">
          {/* Orange on STATUTORY, quiet on REGULATORY - the design system's rule, because
              statutory is work EVO actually does and regulatory is a duty that never
              transfers. Painted the other way round it would say "you hold the duty" in EVO
              orange, which is the overclaim this whole page exists to avoid. */}
          {/* Same heading-order fix as /how-it-works: these two cards are h3s and there was no
              h2 between them and the page title. */}
          <h2 className="visually-hidden">Statutory compliance and regulatory compliance</h2>
          <div className="split-halves">
            <div className="card card--statutory">
              <IconBadge name="wrench" />
              <p className="eyebrow">Statutory</p>
              <h3>Gas, electrical, alarms.</h3>
              <p>
                <strong>We do the work.</strong> Inspection, certification and the remedials that follow, carried out by
                the same trades who do your repairs, so a failed check becomes a job rather than a letter.
              </p>
              <p className="mb-0">Available as an add-on to any plan, or as variable works.</p>
            </div>
            <div className="card card--regulatory">
              <IconBadge name="clipboard" />
              <p className="eyebrow">Regulatory</p>
              <h3>The Regulator, TSMs, Awaab&rsquo;s Law.</h3>
              <p>
                <strong>You hold the duty. We hold the proof.</strong> The duty never transfers and we will not pretend
                otherwise. What changes is whether the evidence exists when someone asks for it.
              </p>
              <p className="mb-0">Recorded as the work happens, not assembled afterwards.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--grey">
        <div className="container">
          <SectionHead
            eyebrow="Statutory, in detail"
            title="The certificates, and the work behind them."
            lead="A certificate is the easy part. The hard part is the remedial that the certificate triggers, and getting it done inside the window."
          />
          <div className="grid-2 mt-3">
            <div className="card">
              <IconBadge name="flame" />
              <h3>Gas</h3>
              <ul className="tick-list mb-0">
                <li>Annual gas safety inspection and certificate</li>
                <li>Annual boiler service</li>
                <li>Breakdown repairs, parts and labour</li>
                <li>Controls, flue and associated components</li>
              </ul>
            </div>
            <div className="card">
              <IconBadge name="bolt" />
              <h3>Electrical</h3>
              <ul className="tick-list mb-0">
                <li>EICR inspection and certification</li>
                <li>PAT testing</li>
                <li>Smoke and heat alarm testing</li>
                <li>Visual electrical safety inspection</li>
              </ul>
            </div>
          </div>
          {/* Sam, 27 September: the gas safety photograph belongs with the statutory work it
              shows, not in the regulatory section further down where it had no connection to
              the text beside it. */}
          <div className="mt-3 photo-inset">
            <Photo
              src="/images/photos/evo-engineer-gas-safety-check.webp"
              alt="An EVO engineer completing a gas safety check at a boiler, recording it on a tablet"
              caption="Statutory checks recorded on the job, against the property, as the work happens."
              width={900}
              height={675}
              sizes="(min-width: 900px) 820px, 100vw"
            />
          </div>
          <p className="mt-3 mb-0">
            <Link href="/pricing" className="text-link">
              Electrical and gas cover pricing
            </Link>
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionHead
            eyebrow="Regulatory, in detail"
            title="Four things you are judged on. One evidence trail."
            lead="They are usually managed separately, by different people, against different deadlines. They all draw on the same underlying record."
          />
          <div className="grid-2 mt-3">
            {REGULATORY.map((r) => (
              <div className="card" key={r.k}>
                <IconBadge name={r.icon} />
                <p className="eyebrow">{r.k}</p>
                <h3>{r.h}</h3>
                <p className="mb-0">{r.b}</p>
              </div>
            ))}
          </div>
          {/* The placeholder asked which Tenant Satisfaction Measures EVO reports against,
              "stated precisely". The measures themselves are a published RSH framework, so
              the codes and wording below are the Regulator's, checked against its own
              guidance - not something EVO has to supply. What EVO supplies is the monthly
              pack behind them.
              Worth knowing: there is NO TSM for damp and mould. It reaches the framework
              through TP04, TP05 and the complaints measures, which is why the row below says
              so rather than inventing a code. */}
          {/* Sam, 27 September: does this page need a picture? It had NONE - not one
              photograph on the whole page, only logos and icons, which is why it reads as
              drier than the pages either side of it. The gas safety check is the right one:
              the shot list calls it the image that proves statutory work is delivered rather
              than just recorded, which is this page's whole argument. */}
          {/* Sam, 27 September: TP02 to TP05 are all tenant PERCEPTION measures - what the
              resident thinks - so the section should show a resident rather than only a
              table of codes. */}
          <div className="ev3-split ev3-split--narrow mt-3">
            <Photo
              src="/images/photos/evo-team-member-helping-resident.webp"
              alt="An EVO team member helping a resident with a repair on their doorstep"
              caption="The measures below are what this resident would say about us."
              width={1400}
              height={787}
              sizes="(min-width: 880px) 40vw, 100vw"
            />
            <div className="tsm">
              <p className="eyebrow">The measures a repairs service moves</p>
              <ul className="tsm-list">
                <li>
                  <span className="tsm-code">TP02</span>
                  <span className="tsm-name">Satisfaction with the overall repairs service in the last 12 months</span>
                </li>
                <li>
                  <span className="tsm-code">TP03</span>
                  <span className="tsm-name">Satisfaction with the time taken to complete the most recent repair</span>
                </li>
                <li>
                  <span className="tsm-code">TP04</span>
                  <span className="tsm-name">
                    Satisfaction that the landlord provides a home that is well maintained
                  </span>
                </li>
                <li>
                  <span className="tsm-code">TP05</span>
                  <span className="tsm-name">Satisfaction that the landlord provides a home that is safe</span>
                </li>
                <li>
                  <span className="tsm-code">RP02</span>
                  <span className="tsm-name">Repairs completed within the target timescale you have set</span>
                </li>
              </ul>
              <p className="tsm-note mb-0">
                TP02 to TP05 are tenant perception measures and RP02 is management information. There is no TSM for damp
                and mould specifically: it reaches the framework through TP04, TP05 and the complaints measures.
                Your monthly pack carries the underlying data for each of these, by property and by month, so the annual
                return is assembled from a record rather than reconstructed.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--grey">
        <div className="container">
          <SectionHead
            eyebrow="The evidence"
            title="What gets recorded, and when."
            lead="Nothing here is assembled after a complaint. It is captured as the job runs, because that is the only way it is worth anything eighteen months later."
          />
          <div className="grid-3 mt-3">
            {RECORDED.map(([k, v]) => (
              <div className="tile" key={k}>
                <p className="eyebrow">{k}</p>
                <p className="mb-0">{v}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionHead
            eyebrow="Damp and mould"
            title="The one we are asked about most."
            lead="A defined procedure rather than a repaint: a moisture reading that decides whether treatment can start, a three-stage treatment, and the before, during and after evidence."
          />
          <div className="statrow statrow--orange mt-3">
            <div>
              <span className="stat stat--orange">1,000+</span>
              <span className="stat-label">Cases handled in 18 months</span>
            </div>
            <div>
              <span className="stat stat--orange">6&ndash;7 days</span>
              <span className="stat-label">Average damp and mould resolution</span>
            </div>
            <div>
              <span className="stat stat--orange">20%</span>
              <span className="stat-label">Moisture threshold below which treatment proceeds</span>
            </div>
          </div>
          <p className="mt-3 mb-0">
            <Link href="/damp-and-mould" className="text-link">
              The full damp and mould procedure
            </Link>
          </p>
        </div>
      </section>

      <section className="section section--grey">
        <div className="container">
          <SectionHead
            eyebrow="Where the line sits"
            title="We are careful about what we do and do not take on."
            lead="It matters more here than anywhere else on this site, because the wrong claim would leave you exposed rather than covered."
          />
          <div className="grid-2 mt-3">
            <div className="card">
              <IconBadge name="shieldCheck" />
              <h3>What we take on</h3>
              <ul className="tick-list mb-0">
                <li>Carrying out statutory inspections and the remedials that follow</li>
                <li>Delivering repairs inside the timescales that apply</li>
                <li>Recording the evidence, as the work happens</li>
                <li>Reporting it to you in a form you can hand to a regulator or a board</li>
              </ul>
            </div>
            <div className="card card--grey">
              <IconBadge name="scales" />
              <h3>What stays with you</h3>
              {/* This list deliberately has no ticks. The paired card opposite is a list of
                  things EVO does; ticking the duties that stay with the landlord would read
                  as though we were claiming them. */}
              <ul className="plain-list mb-0">
                <li>
                  The legal duty, in every case. It does not transfer to a supplier and nobody can take it from you.
                </li>
                <li>The decision on what work is done, and when</li>
                <li>Your relationship with the Regulator and the Ombudsman</li>
                <li>The consumer standards judgement itself</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--warm">
        <div className="container">
          <SectionHead
            eyebrow="Before 30 November"
            title="Can you evidence a repair from eighteen months ago?"
            lead="That is the question Awaab's Law phase 2 turns into a practical one. If the answer involves searching an inbox, the evidence does not exist in any useful sense."
          />
          <div className="btn-row mt-3">
            <Link href={cta.review.href} className="btn btn-primary">
              {cta.review.label}
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
